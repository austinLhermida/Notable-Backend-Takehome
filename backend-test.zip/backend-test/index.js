
// Import express
const express = require('express')
const app = express()
// Express json-parser used to implement an initial handler for dealing with HTTP POST requests 
app.use(express.json())

// raw doctor/appointment data stored in JSON
let doctors = [
    {
        id: 1,
        firstName: 'Julius',
        lastName: 'Hibbert'
    },
    {
        id: 2,
        firstName: 'Algernop',
        lastName: 'Krieger'
    },
    {
        id: 3,
        firstName: 'Nick',
        lastName: 'Riviera'
    }
  ]

let appointments = [
    {
        id: 1,
        patientFirst: 'Sterling',
        patientLast: 'Archer',
        date: '05-09-2018',
        time: '8:00AM',
        kind: 'New Patient',
        doctorFirst: 'Julius',
        doctorLast: 'Hibbert' 
    },
    {
        id: 2,
        patientFirst: 'Cyril',
        patientLast: 'Figis',
        date: '05-09-2018',
        time: '8:00AM',
        kind: 'Follow-up',
        doctorFirst: 'Julius',
        doctorLast: 'Hibbert' 
    },
    {
        id: 3,
        patientFirst: 'Ray',
        patientLast: 'Gilette',
        date: '05-09-2018',
        time: '8:00AM',
        kind: 'Follow-up',
        doctorFirst: 'Julius',
        doctorLast: 'Hibbert' 
    },
    {
        id: 4,
        patientFirst: 'Lana',
        patientLast: 'Kane',
        date: '05-09-2018',
        time: '9:30AM',
        kind: 'New Patient',
        doctorFirst: 'Julius',
        doctorLast: 'Hibbert' 
    },
    {
        id: 5,
        patientFirst: 'Pam',
        patientLast: 'Poovey',
        date: '05-09-2018',
        time: '10:00AM',
        kind: 'New Patient',
        doctorFirst: 'Julius',
        doctorLast: 'Hibbert'  
    },
    {
        id: 6,
        patientFirst: 'Austin',
        patientLast: 'Hermida',
        date: '05-10-2018',
        time: '11:00AM',
        kind: 'New Patient',
        doctorFirst: 'Algernop',
        doctorLast: 'Krieger'  
    },
    {
        id: 7,
        patientFirst: 'Justin',
        patientLast: 'Hermida',
        date: '05-11-2018',
        time: '8:00AM',
        kind: 'New Patient',
        doctorFirst: 'Nick',
        doctorLast: 'Riviera'  
    }
]


// route 1: default route 
app.get('/', (request, response) => {
    response.send(
        '<h1> Hi Notable Health! Check the documentation for a list of endpoints</h1>'
        )
})

// route 2a: GET request for a list of all doctors 
app.get('/api/doctors', (request, response) => {   
    response.json(doctors)
})

// route 2b: GET request for a list of all appointments
app.get('/api/appointments', (request, response) => {   
    response.json(appointments)
})

// route 3a: GET request for all appointments for a specific doctor 
app.get('/api/:doctorFirst/:doctorLast/appointments', (request, response) => {
    // end point example: /api/Nick/Riviera/appointments
    const doctorFirst = request.params.doctorFirst;
    const doctorLast = request.params.doctorLast;

    const allAppointments = appointments.filter( appointment => appointment.doctorFirst === doctorFirst && appointment.doctorLast == doctorLast)
    
    // error handling to check if the doctor's name exists
    if (allAppointments.length !== 0) {
        response.json(allAppointments);
    }
    else {
        response.status(404).end();
    }
})

// route 3b: GET request for one specific appointment based on id
app.get('/api/appointments/:id', (request, response) => {
    // end point example: /api/appointments/7
    const id = Number(request.params.id)

    const allAppointments = appointments.filter( appointment => appointment.id === id)
    
    // error handling to check if the doctor's name exists
    if (allAppointments.length !== 0) {
        response.json(allAppointments);
    }
    else {
        response.status(404).end();
    }
})

// route 4: GET request for all appointments on a particular day
app.get('/api/appointments/:date', (request, response) => {
    // end point example: /api/appointments/05-09-2018
    const date = request.params.date;

    const allAppointments = appointments.filter( appointment => appointment.date === date)
    
    // error handling to check if appointments on that date exist
    if (allAppointments.length !== 0) {
        response.json(allAppointments);
    }
    else {
        response.status(404).end();
    }
})


// route 5: delete an existing appointment in a specific doctor's calendar 
// each appointment has a unique id, so we do not need to specify a doctor
app.delete('/api/appointments/:id', (request, response) => {
    // end point example: /api/appointments/7
    const id = Number(request.params.id)
    appointments = appointments.filter(appointment => appointment.id !== id)

    response.status(204).end()
})

const generateId = () => {
    const maxId = appointments.length > 0
      ? Math.max(...appointments.map(n => n.id))
      : 0
    return maxId + 1
  }

// route 6: add/post a new appointment to a doctor's calendar
// requirements: 
    // new appointments can only start at 15 minute intervals (8:00 > 8:15 > 8:30 > 8:45)
    // doctor can have only up to 3 appointments at the same time  
app.post('/api/:doctorFirst/:doctorLast/appointments', (request, response) => {
    // end point example: /api/Nick/Riviera/appointments
    const body = request.body;
    const doctorFirst = request.params.doctorFirst;
    const doctorLast = request.params.doctorLast;

    // Requirement #1 where an appointment can only start at 15 minute intervals 
    const timeAsArray = body.time.split('');
    let minutes = [];

    for (let i = 0; i < timeAsArray.length; i++) {
        if (timeAsArray[i] === ':') {
            minutes.push(timeAsArray[i+1])
            minutes.push(timeAsArray[i+1])
            break;
        }
    }

    let minutesAsNum = parseInt(minutes.toString())

    if (minutesAsNum % 15 !== 0) {
        return response.status(400).json({
            error: `You entered an appointment time at ${body.time}. New appointments can only start at 15 minute intervals (ie, 8:15AM is a valid time but 8:20AM is not)`
        })

    }
    
    // Requirement #2 where a doctor can only have 3 appointmetns at the same time 
    let doctorsAppointments = appointments.filter( appointment => appointment.doctorFirst === doctorFirst && appointment.doctorLast == doctorLast)
    let simultaneousAppointments = doctorsAppointments.filter( appointment => appointment.time === body.time)
    if (simultaneousAppointments.length >= 3) {
        return response.status(400).json({
            error: `Dr. ${doctorFirst} ${doctorLast} already has 3 appointments booked at ${body.time}`
        })
    }
  
    const appointment = {
        id: generateId(),
        patientFirst: body.patientFirst,
        patientLast: body.patientLast,
        date: body.date,
        time: body.time,
        kind: body.kind,
        doctorFirst: doctorFirst,
        doctorLast: doctorLast
    }
  
    appointments = appointments.concat(appointment)

    response.json(appointments)
})

const unknownEndpoint = (request, response) => {
    response.status(404).send({ error: 'unknown endpoint' })
  }
  
  app.use(unknownEndpoint)

// listens for HTTP requests sent to port 3001 
const PORT = 3001
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`)
  })